// var arr = ["shazra", "noor", "hassan", "bushra"];
// var search = prompt("Search");
// var uppercase = search.toLowerCase();
// for (var i = 0; i < arr.length; i++) {
//     if (uppercase === arr[i]) {
//         alert("Available " + search)
//         break
//     } else { 
//         alert("Sorry")
//     }
// }

// var num = + prompt("Enter a number for table");
// var limit = + prompt("Enter limit");
// for (var i = 1; i <= limit; i++) {
//     var table = num + " x " + i + " = " + i * num + "<br> ";
//     document.write(table);
// }

// var arr = ["Shazra", "Noor", "Hassan", "Javed"];
// var input = prompt("Enter Name");
// var firstChar = input.slice(0, 1)
// var otherChar = input.slice(1)
// var fullname = firstChar.toUpperCase() + otherChar.toLowerCase()
// console.log(fullname);

// for (var i = 0; i < arr.length; i++) {
//     console.log(arr[i])
//     if (fullname === arr[i]) {
//         alert("Available")
//         break
//     } else {
//         alert("Not Available")
//     }
// }


// var input = prompt ("Enter entity");
// // var firstletter = input.slice(0,1);
// // var otherletter = input.slice(1);
// // var entity = firstletter.toUpperCase() + otherletter.toLowerCase();
// console.log(input.length);

// var input = prompt ("Enter entity");
// var firstletter = input.slice(0,1);
// var otherletter = input.slice(1);
// var letter = firstletter.toUpperCase() + otherletter.toLowerCase();
// console.log(letter);

// var num = 1.2;
// var round = Math.round(num);
// console.log(round);

// var num = Math.random() * 10;
// var num1 = Math.round(num)
// console.log(num1);

// var head = prompt ("Enter headuser Name");
// var tail = prompt ("Enter tailuser name");
// var toss = Math.random() * 2;
// var floor = Math.round(toss);
// if(floor === 0){
//     alert("Head " + head + " win the toss")
// }else{
//     alert("Tail " + tail + " win the toss")
// }

//                                           task
// var num = Math.random() * 10;
// var num1 = Math.round(num);
// console.log(num1);
// if (num1 % 2 === 0 ){
//     alert("This even number")
// }else{
//     alert("This is odd number")
// }

// var today = new Date();
// console.log(today)

//                                            task
// var dob = new Date(prompt ("Enter your date of birth" , "oct 8 ,1997"));
// var dobmili = dob.getTime();
// var today = new Date();
// var todaymili = today.getTime();
// var diff = todaymili - dobmili;
// var accu_age = Math.floor(diff/(1000 * 60 * 60 * 24 * 30 * 12));
// console.log(accu_age);
// if(accu_age >= 18){
//     alert("Welcome!")
// }else{
//     alert("Sorry!")
// }

// function calculator() {
//     var f_num = +prompt("Enter first integer");
//     var s_num = +prompt("Enter second integer");
//     var opr = prompt("Enter operator");
//     if (opr === "+") {
//         alert("Your sum is equal to " + (f_num + s_num))
//     } else if (opr === "-") {
//         alert("Your subraction is equal to " + (f_num-s_num))
//     } else if (opr === "x" || "*") {
//         alert("Your Multiplication is equal to " + (f_num * s_num))
//     } else if (opr === "/") {
//         alert("Your division is equal to " + (f_num / s_num))
//     } else if (opr === "%") {
//         alert("Your Remainder is equal to " + (f_num % s_num))
//     } else {
//         alert("undefined")
//     }
// }
// calculator();

// function abc(){
//     var input = prompt("Enter Your first Name");
//     var inp_s= prompt("Enter second name");
//     document.write(input);
//     document.write(inp_s);
// }



